
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;


public class ViewImage extends JFrame{
    
    public String[] list;
    public File f,file;
    public int counter=0;
    public int flag=0;
    public Timer time;
    public int degree=90;

    public ViewImage(){
        this.setBounds(0,0,800,600);
        this.setTitle("Image Viewer");
        this.setLayout(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        JLabel image=new JLabel();
        image.setBounds(30,15,700,400);
        
        JButton open=new JButton();
        open.setText("Open Image");
        open.setBounds(120,450,110,50);
        open.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    JFileChooser choose=new JFileChooser();
                    choose.showOpenDialog(null);
                    file=choose.getSelectedFile();
                    f=choose.getCurrentDirectory();
                    String path=file.getAbsolutePath();
                    BufferedImage img = ImageIO.read(file);
                    image.setIcon(new ImageIcon(resize(img)));
                    list=f.list();
                    setTitle("Image Viewer- "+file.getName());
                    for(int i=0;i<list.length;i++){
                        if(list[i].equals(file.getName())){
                            counter=i;
                            break;
                        }
                    }
                } catch (IOException ex1) {
                    JOptionPane.showMessageDialog(null, ex1.getMessage());
                }
            }
        });
        
        JButton next=new JButton();
        next.setText("Next");
        next.setBounds(240,450,100,50);
        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                counter++;
                flag=1;
                if(counter==list.length){
                    counter=0;
                }
                if(list[counter].contains("jpg") || list[counter].contains("png")){
                    BufferedImage img=null;
                    File nextFile=new File(f+"\\"+list[counter]);
                    setTitle("Image Viewer- "+list[counter]);
                    try {
                        img = ImageIO.read(nextFile);
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, ex.getMessage());
                    }
                    image.setIcon(new ImageIcon(resize(img)));
                }
            }
        });
        
        JButton previous=new JButton();
        previous.setText("Previous");
        previous.setBounds(10,450,100,50);
        previous.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                counter--;
                if(counter<0){
                    counter=list.length-1;
                }
                flag=2;
                if(list[counter].contains("jpg") || list[counter].contains("png")){
                    BufferedImage img=null;
                    File nextFile=new File(f+"\\"+list[counter]);
                    setTitle("Image Viewer- "+list[counter]);
                    try {
                        img = ImageIO.read(nextFile);
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, ex.getMessage());
                    }
                    image.setIcon(new ImageIcon(resize(img)));
                }
            }
        });
        
        JButton crop=new JButton();
        crop.setText("Crop");
        crop.setBounds(350,450,100,50);
        crop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String a=JOptionPane.showInputDialog("Enter height: ");
                    int b=Integer.parseInt(a);
                    String c=JOptionPane.showInputDialog("Enter width");
                    int d=Integer.parseInt(c);
                    File cropFile = null;
                    if(flag==0){
                        cropFile=new File(f+"\\"+list[counter]);
                    }else if(flag==1){
                        cropFile=new File(f+"\\"+list[counter-1]);
                    }else if(flag==2){
                        cropFile=new File(f+"\\"+list[counter]);
                    }
                    BufferedImage img=ImageIO.read(cropFile);
                    BufferedImage cropped=(BufferedImage) resizeImage(img, b, d);
                    image.setIcon(new ImageIcon(cropped));
                    JFileChooser save=new JFileChooser();
                    save.showSaveDialog(null);
                    File saved=new File(save.getSelectedFile()+".jpg");
                    ImageIO.write(cropped,"jpg",saved);
                }catch(Exception ex){
                    
                }
            }
        });
        
        JButton slide=new JButton();
        slide.setText("Start Slide Show");
        slide.setBounds(460,450,130,50);
        slide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                time=new Timer(3000, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        counter++;
                        if(list[counter].contains("jpg") || list[counter].contains("png")){
                            BufferedImage img=null;
                            File nextFile=new File(f+"\\"+list[counter]);
                            setTitle("Image Viewer- "+list[counter]);
                            try {
                                img = ImageIO.read(nextFile);
                            } catch (IOException ex) {
                                JOptionPane.showMessageDialog(null, ex.getMessage());
                            }
                            image.setIcon(new ImageIcon(resize(img)));
                        }
                        if(counter>=list.length-1){
                            counter=0;
                        }else if(counter<0){
                            counter=list.length-1;
                        }
                    }
                });
                time.start();
            }
        });
        
        JButton stopSlide=new JButton();
        stopSlide.setText("Stop Slide Show");
        stopSlide.setBounds(600,450,130,50);
        stopSlide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                time.stop();
            }
        });
        
        JButton rotateButton=new JButton();
        rotateButton.setText("Rotate Image");
        rotateButton.setBounds(300,510,130,50);
        rotateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    File rotateFile = null;
                    if(flag==0){
                        rotateFile=new File(f+"\\"+list[counter]);
                    }else if(flag==1){
                        rotateFile=new File(f+"\\"+list[counter-1]);
                    }else if(flag==2){
                        rotateFile=new File(f+"\\"+list[counter]);
                    }
                    BufferedImage img=ImageIO.read(rotateFile);
                    BufferedImage rotate=(BufferedImage)rotateImage(img,400,700);
                    image.setIcon(new ImageIcon(resize(rotate)));
                    JFileChooser save=new JFileChooser();
                    save.showSaveDialog(null);
                    File saved=new File(save.getSelectedFile()+".jpg");
                    ImageIO.write(rotate,"jpg",saved);
                } catch (IOException ex) {
                    Logger.getLogger(ViewImage.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        
        this.add(open);
        this.add(image);
        this.add(crop);
        this.add(next);
        this.add(previous);
        this.add(slide);
        this.add(stopSlide);
        this.add(rotateButton);
    }
    
    public Image resize(Image img){
        BufferedImage r=new BufferedImage(700, 400, BufferedImage.TYPE_INT_RGB);
        Graphics2D g=r.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(img, 0, 0,700,400,null);
        g.dispose();
        return r;
    }
    
    public Image resizeImage(Image img,int height,int width){
        BufferedImage r=new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g=r.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(img, 0, 0,height,width,null);
        g.dispose();
        return r;
    }
    
    public Image rotateImage(BufferedImage img,int height,int width){
        BufferedImage r=new BufferedImage(width,height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d=r.createGraphics();
        AffineTransform tx = AffineTransform.getTranslateInstance(-700, -400);
        tx.rotate(Math.toRadians(degree),img.getWidth()/2,img.getHeight()/2);
        AffineTransformOp op = new AffineTransformOp(tx, AffineTransformOp.TYPE_BILINEAR);
        g2d.drawImage(img,tx,null);
        g2d.dispose();
        degree+=90;
        return r;
    }

    public static void main(String[] args) {
        ViewImage view=new ViewImage();
        view.setVisible(true);
    }
    
}
